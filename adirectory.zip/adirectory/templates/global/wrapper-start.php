<?php

/**
 * The Template for displaying content wrappers
 *
 * This template can be overridden by copying it to yourtheme/adirectory/global/wrapper-start.php.
 *

 * @package     QS Directories\Templates
 * @version     1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<div class="qsd-content-area">
