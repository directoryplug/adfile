<?php

/**
 * The template for displaying listing descrption content in the single-listing.php template
 *
 * This template can be overridden by copying it to yourtheme/adirectory/single-listing/desciption.php.
 *
 * @package     QS Directories\Templates
 * @version     1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
<div class="listing-grid-details-txt-item">
    <?php the_content();?>
</div>