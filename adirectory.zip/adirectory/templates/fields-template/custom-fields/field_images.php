<?php
if (!defined('ABSPATH')) {
	return '';
}
