<?php

namespace ADQS_Directory\Admin;

if (! defined('ABSPATH')) {
	exit; // Exit if accessed directly
}
/**
 * Api handlers class
 */
class Api
{


	/**
	 * Class constructor
	 */
	function __construct() {}
}
