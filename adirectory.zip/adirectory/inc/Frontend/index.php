<?php
// Be kind to everyone even if he is your enemy.
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}